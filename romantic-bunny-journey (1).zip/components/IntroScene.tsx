import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface IntroSceneProps {
  onNext: () => void;
}

const IntroScene: React.FC<IntroSceneProps> = ({ onNext }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full w-full p-6 text-center">
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
        className="mb-8 relative"
      >
        {/* A cute bunny image */}
        <div className="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-white shadow-2xl relative z-10">
          <img 
            src="https://images.unsplash.com/photo-1585110396093-6e3a22830dc5?q=80&w=1000&auto=format&fit=crop" 
            alt="Cute Bunny"
            className="w-full h-full object-cover"
          />
        </div>
        
        {/* Decorative elements behind */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -inset-4 border-2 border-dashed border-romantic-400 rounded-full z-0 opacity-50"
        />
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        className="text-4xl md:text-5xl font-cursive text-romantic-800 mb-12 drop-shadow-sm"
      >
        欢迎来到兔兔的专属空间
      </motion.h1>

      <motion.button
        whileHover={{ scale: 1.1, boxShadow: "0px 0px 15px rgba(244, 63, 94, 0.5)" }}
        whileTap={{ scale: 0.95 }}
        onClick={onNext}
        className="group relative px-8 py-4 bg-white text-romantic-600 font-serif text-xl rounded-full shadow-lg border-2 border-romantic-200 flex items-center gap-2 transition-all"
      >
        <span>Enter</span>
        <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
      </motion.button>
    </div>
  );
};

export default IntroScene;