import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';

interface HeartSceneProps {
  onComplete: () => void;
}

const HeartScene: React.FC<HeartSceneProps> = ({ onComplete }) => {
  const [exploded, setExploded] = useState(false);

  // Number of small hearts to spawn
  const particleCount = 24;
  const particles = Array.from({ length: particleCount });

  const handleCenterClick = () => {
    if (exploded) return;
    setExploded(true);
    
    // Auto proceed after animation (approx 4 seconds total)
    setTimeout(() => {
      onComplete();
    }, 4500);
  };

  return (
    <div className="w-full h-full flex items-center justify-center relative bg-romantic-50/50">
      
      {/* Central Heart (Initial State) */}
      <motion.div
        animate={exploded ? { scale: 0, opacity: 0 } : { scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="z-50 cursor-pointer"
        onClick={handleCenterClick}
      >
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <Heart 
            fill="#f43f5e" 
            stroke="#be123c" 
            strokeWidth={1}
            size={120} 
            className="drop-shadow-xl text-romantic-500"
          />
        </motion.div>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center mt-4 text-romantic-700 font-serif text-lg font-bold"
        >
          点我
        </motion.p>
      </motion.div>

      {/* Exploded Particles */}
      {exploded && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {particles.map((_, i) => {
            const angle = (i / particleCount) * 2 * Math.PI;
            const radius = 150; // Orbit radius
            // Calculate target position for orbit start
            const tx = Math.cos(angle) * radius;
            const ty = Math.sin(angle) * radius;

            return (
              <motion.div
                key={i}
                className="absolute"
                initial={{ x: 0, y: 0, scale: 0, opacity: 1 }}
                animate={{
                  x: tx, 
                  y: ty, 
                  scale: 1, 
                  transition: { duration: 0.8, ease: "easeOut" } 
                }}
              >
                {/* 
                  Step 2: Orbit logic. 
                  We rotate the parent container or the item itself. 
                  To make them orbit AROUND the center, we can animate the rotation of a container wrapper,
                  but here we are animating the items directly. 
                  
                  Tricky part with Framer Motion: Circular orbit without container rotation requires keyframes for X/Y.
                  Easier approach: Wrap each particle in a rotator div that starts at center?
                  
                  Let's use a simpler "swirl" animation on the individual particle by rotating the frame of reference 
                  via a transform, or just use a layout animation.
                  
                  Let's use a nested structure for the orbit.
                */}
                <OrbitingHeart delay={0.8} radius={radius} initialAngle={angle} />
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// Helper component to handle the circular orbit motion after the initial explosion
const OrbitingHeart: React.FC<{ delay: number; radius: number; initialAngle: number }> = ({ delay, radius, initialAngle }) => {
  return (
    <motion.div
      // We are already at (tx, ty) relative to center from the parent's animate
      // But actually, the parent animate leaves us at a static position.
      // Let's reset and do the orbit math.
      // To make it orbit, we can treat the center as (0,0) and animate the angle.
      // However, CSS transforms are easier for orbits: Rotate a container that holds the heart at an offset.
      
      // Let's ignore the parent translate and do it all here.
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
      }}
      initial={{ rotate: 0 }} // This rotation is around the screen center if we structure it right
      animate={{ rotate: 360 * 2 }} // 2 Full rotations
      transition={{ 
        delay: delay, 
        duration: 3.5, 
        ease: "linear" 
      }}
    >
       {/* 
         The trick: The outer div rotates around the screen center (0,0).
         The inner div is offset by Radius.
         BUT, the initial explosion moved them to Radius.
         
         Let's restructure:
         The parent loop in HeartScene places them at (0,0).
         We scale up a container that is rotated to the correct angle?
       */}
       <div 
        style={{ 
          transform: `rotate(${initialAngle}rad) translateX(${0}px)` 
          // Initial state: We need to animate the translateX from 0 to Radius, then Rotate the whole thing.
        }} 
       >
         {/* This is getting complex to coordinate cleanly with the explode.
             Alternative: Just animate the heart icon itself.
         */}
       </div>
    </motion.div>
  );
};

// Re-implementing a simpler version of the explosion + orbit without complex nesting
// We will simply have a container for each particle that rotates.
// 1. Particle starts at center.
// 2. Particle moves OUT to Radius (Explosion).
// 3. Container rotates 720 degrees (Orbit).

const SimpleParticle: React.FC<{ index: number; total: number }> = ({ index, total }) => {
    const angleDeg = (index / total) * 360;

    return (
        <motion.div
            className="absolute top-1/2 left-1/2 w-0 h-0 flex items-center justify-center"
            initial={{ rotate: angleDeg }}
            animate={{ rotate: angleDeg + 720 }} // Rotate 2 full circles + initial angle
            transition={{ 
                delay: 0.6, // Wait for explosion to finish
                duration: 3, 
                ease: "linear" 
            }}
        >
            <motion.div
                initial={{ x: 0, scale: 0 }}
                animate={{ x: 120, scale: 1 }} // Move outward 120px
                transition={{ 
                    duration: 0.6, 
                    ease: "easeOut" 
                }}
            >
                <Heart size={24} fill="#fb7185" className="text-romantic-500" />
            </motion.div>
        </motion.div>
    )
}

// Override the main component render to use SimpleParticle
const HeartSceneRevised: React.FC<HeartSceneProps> = ({ onComplete }) => {
    const [exploded, setExploded] = useState(false);
    const particleCount = 20;
  
    const handleCenterClick = () => {
      if (exploded) return;
      setExploded(true);
      setTimeout(onComplete, 4000); // 0.6s explode + 3s orbit + buffer
    };
  
    return (
      <div className="w-full h-full flex items-center justify-center relative bg-white overflow-hidden">
        {/* Center Button */}
        <AnimatePresence>
            {!exploded && (
                <motion.div
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="z-50 cursor-pointer flex flex-col items-center"
                    onClick={handleCenterClick}
                >
                    <motion.div
                    animate={{ scale: [1, 1.15, 1] }}
                    transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
                    >
                        <Heart fill="#e11d48" stroke="none" size={100} className="drop-shadow-lg text-romantic-600" />
                    </motion.div>
                    <p className="mt-4 text-romantic-800 font-serif font-bold text-xl animate-pulse">点击爱心</p>
                </motion.div>
            )}
        </AnimatePresence>
  
        {exploded && Array.from({ length: particleCount }).map((_, i) => (
            <SimpleParticle key={i} index={i} total={particleCount} />
        ))}
      </div>
    );
};

export default HeartSceneRevised;