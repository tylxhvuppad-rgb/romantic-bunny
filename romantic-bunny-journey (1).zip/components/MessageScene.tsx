import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface MessageSceneProps {
  onComplete: () => void;
}

const MESSAGES = [
  "兔兔是我最爱的人",
  "世界上没有值得我们伤心的事",
  "你要开开心心的",
  "这样胜过世间一切",
  "没有任何人比你自己更重要",
  "要好好爱自己！"
];

const MessageScene: React.FC<MessageSceneProps> = ({ onComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    // If we've shown all messages, wait a bit then complete
    if (currentIndex >= MESSAGES.length) {
      const timeout = setTimeout(onComplete, 2000);
      return () => clearTimeout(timeout);
    }

    // Interval to switch to next message
    const interval = setTimeout(() => {
      setCurrentIndex((prev) => prev + 1);
    }, 2800); // Read time per message

    return () => clearTimeout(interval);
  }, [currentIndex, onComplete]);

  // We only render if index is within bounds, but we handle the completion logic above
  const currentMessage = currentIndex < MESSAGES.length ? MESSAGES[currentIndex] : null;

  return (
    <div className="w-full h-full flex items-center justify-center bg-romantic-50 p-4">
      <AnimatePresence mode="popLayout">
        {currentMessage && (
          <motion.div
            key={currentIndex} // Key change triggers animation
            initial={{ y: 100, opacity: 0, scale: 0.8 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -100, opacity: 0, scale: 1.1 }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
            className="absolute text-center"
          >
            <h2 className="text-3xl md:text-5xl font-cursive text-romantic-900 drop-shadow-md leading-relaxed">
              {currentMessage}
            </h2>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MessageScene;