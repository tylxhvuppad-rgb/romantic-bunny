import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Flower2 } from 'lucide-react';

interface FinaleSceneProps {
  onReset: () => void;
}

const TEXT_ITEMS = [
  "兔兔是我最爱的人",
  "世界上没有值得我们伤心的事",
  "你要开开心心的",
  "这样胜过世间一切",
  "没有任何人比你自己更重要",
  "要好好爱自己！"
];

// Combine all text to form the boundary
const ALL_TEXT = TEXT_ITEMS.join(" ❤ ");

const FinaleScene: React.FC<FinaleSceneProps> = ({ onReset }) => {
  const [roseExploded, setRoseExploded] = useState(false);

  // Generate positions for the text to form a heart
  const textPositions = useMemo(() => {
    const points = [];
    const totalChars = ALL_TEXT.length;
    
    for (let i = 0; i < totalChars; i++) {
        const t = (i / totalChars) * 2 * Math.PI; 
        
        // Heart formulas
        // Scale factor 's' to fit screen
        // We use a base scale, and rely on CSS transform for responsiveness
        const s = 12; 
        const x = s * (16 * Math.pow(Math.sin(t), 3));
        const y = -1 * s * (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));

        points.push({ x, y, char: ALL_TEXT[i] });
    }
    return points;
  }, []);

  const handleRoseClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setRoseExploded(true);
  };

  const handleScreenClick = () => {
    if (roseExploded) {
      onReset();
    }
  };

  return (
    <div 
      className={`w-full h-full relative overflow-hidden bg-romantic-100 cursor-${roseExploded ? 'pointer' : 'default'} select-none`}
      onClick={handleScreenClick}
    >
      {/* Screen Shake Container */}
      <motion.div 
        className="w-full h-full flex items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        {/* Animated Wrapper for Shake to allow control */}
        <div className="animate-shake origin-center">
            {/* Heart Text Shape - Scaled for mobile */}
            <div className="relative w-[400px] h-[400px] md:w-[600px] md:h-[600px] flex items-center justify-center scale-75 md:scale-100">
                {textPositions.map((pos, i) => (
                    <motion.span
                        key={i}
                        initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                        animate={{ 
                            x: pos.x, 
                            y: pos.y, 
                            opacity: 1, 
                            scale: 1 
                        }}
                        transition={{ 
                            delay: 0.8 + (i * 0.03), // Stagger the appearance
                            type: 'spring',
                            stiffness: 120
                        }}
                        className="absolute text-romantic-900 font-serif font-bold text-lg md:text-xl whitespace-nowrap"
                        style={{
                            textShadow: '0px 0px 3px rgba(255, 255, 255, 0.8)'
                        }}
                    >
                        {pos.char}
                    </motion.span>
                ))}
                
                {/* Center Rose */}
                <AnimatePresence>
                    {!roseExploded && (
                        <motion.div
                            className="absolute z-50 cursor-pointer hover:scale-110 transition-transform inset-0 flex items-center justify-center"
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            exit={{ scale: 3, opacity: 0 }}
                            transition={{ delay: 2.5, duration: 0.5 }}
                            onClick={handleRoseClick}
                        >
                            <div className="relative flex flex-col items-center justify-center">
                                <div className="relative">
                                    <Flower2 size={80} className="text-red-600 drop-shadow-2xl" strokeWidth={1.5} />
                                    <motion.div 
                                        className="absolute inset-0 rounded-full bg-red-400 opacity-20"
                                        animate={{ scale: [1, 1.5, 1], opacity: [0.2, 0, 0.2] }}
                                        transition={{ repeat: Infinity, duration: 2 }}
                                    />
                                </div>
                                <motion.p 
                                    className="absolute -bottom-10 text-romantic-800 font-serif whitespace-nowrap text-lg font-bold"
                                    initial={{ opacity: 0, y: -10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 3.5 }}
                                >
                                    送给你
                                </motion.p>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
      </motion.div>

      {/* Rose Explosion Overlay */}
      {roseExploded && (
         <div className="absolute inset-0 pointer-events-none overflow-hidden z-50">
            {/* Generate random roses all over the screen */}
            {Array.from({ length: 60 }).map((_, i) => (
                <RoseParticle key={i} />
            ))}
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.5 }}
                className="absolute bottom-10 w-full text-center text-romantic-900 font-cursive text-2xl drop-shadow-md px-4"
            >
                再次点击屏幕回到起点
            </motion.div>
         </div>
      )}
    </div>
  );
};

const RoseParticle: React.FC = () => {
    // Random positions
    const randomX = Math.random() * 100; // vw
    const randomY = Math.random() * 100; // vh
    const delay = Math.random() * 0.5;
    const duration = 0.8 + Math.random();
    const scale = 0.5 + Math.random() * 1.5;

    return (
        <motion.div
            className="absolute"
            style={{ left: '50%', top: '50%' }} // Start from center
            initial={{ x: 0, y: 0, scale: 0, rotate: 0 }}
            animate={{ 
                left: `${randomX}%`, 
                top: `${randomY}%`, 
                scale: scale, 
                rotate: Math.random() * 360 + 180
            }}
            transition={{ duration: duration, delay: delay, ease: "easeOut" }}
        >
             <Flower2 size={32} className="text-red-500/90 drop-shadow-sm" strokeWidth={1} fill="#fda4af" />
        </motion.div>
    )
}

export default FinaleScene;